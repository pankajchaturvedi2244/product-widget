export const MAX_QUERY_LENGTH = 500;
export const MAX_PRICE_LIMIT = 5000;
